package com.ApiAagenda.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.Aagenda.modelo.TContacto;

@Repository
public class agendadaoImplementacion implements Agendadao {

	
	@Autowired
	AgendaJPAspring agenda;
	
	
	@Override
	public void agregar(TContacto contacto) {
		// TODO Auto-generated method stub
		agenda.save(contacto);//sentencia insert (SQL)
	}

	@Override
	public TContacto recuperarContacto(String email) {
		// TODO Auto-generated method stub
		return agenda.findByEMail(email);
	}

	@Override
	public void deleteContacto(String email) {
		// TODO Auto-generated method stub
		agenda.eliminarContacto(email);
	}

	@Override
	public List<TContacto> devuelveContactos() {
		// TODO Auto-generated method stub
		return agenda.findAll();
	}

	@Override
	public void delecteContacto(int idcontacto) {
		// TODO Auto-generated method stub
		agenda.deleteById(idcontacto);
	}

	@Override
	public TContacto recuperarContacto(int idcontacto) {
		// TODO Auto-generated method stub
		return  agenda.findById(idcontacto).orElse(null);
	}

	@Override
	public void actualizarContacto(TContacto contacto) {
		// TODO Auto-generated method stub
		agenda.save(contacto);
	}

}
