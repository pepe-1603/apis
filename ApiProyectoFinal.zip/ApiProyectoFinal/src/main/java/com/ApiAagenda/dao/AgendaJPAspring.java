package com.ApiAagenda.dao;

import javax.transaction.Transactional;

import org.springframework.data.jdbc.repository.query.Modifying;
import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.jpa.repository.JpaRepository;

import com.Aagenda.modelo.TContacto;

/*agregamos funciones que podriamos personalizar*/

public interface AgendaJPAspring extends JpaRepository<TContacto, Integer>{
//en este caso ceraremos un metodo para buscar/eliminar un contacto por email (String)
	
	TContacto findByEMail(String eMail);//busqeuda por  email
	@Transactional
	@Modifying
	/*nota ? signifca que cuando queramo eliminar,a 1er var que vea funcion*/
	@Query("delete * from t_contacto c where c.e_mail=?1")
	void eliminarContacto(String email);
}
