package com.ApiAagenda.dao;

import java.util.List;

import com.Aagenda.modelo.TContacto;

public interface Agendadao {
	/*interaccion directa con la base de datos 
	 * cuando sea implementada*/
	
	public void agregar(TContacto contacto);//agregar
	TContacto recuperarContacto(String email);//buscar por email
	void deleteContacto(String email);//eliminar contacto por email
	List<TContacto> devuelveContactos();////consulta todos los contactos
	void delecteContacto(int idcontacto);//eliminar contacto por id
	TContacto recuperarContacto(int idcontacto);//busca por id
	void actualizarContacto(TContacto contacto);///actualizar contato (Editar)
}
