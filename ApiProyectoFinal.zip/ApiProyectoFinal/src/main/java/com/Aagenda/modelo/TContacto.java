package com.Aagenda.modelo;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the t_contactos database table.
 * 
 */
@Entity
@Table(name="t_contactos")
@NamedQuery(name="TContacto.findAll", query="SELECT t FROM TContacto t")
public class TContacto implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private String idcontacto;

	@Column(name="e_mail")
	private String eMail;

	private String nacionalidad;

	private String nombre;

	private String telefono;

	public TContacto() {
	}

	public String getIdcontacto() {
		return this.idcontacto;
	}

	public void setIdcontacto(String idcontacto) {
		this.idcontacto = idcontacto;
	}

	public String getEMail() {
		return this.eMail;
	}

	public void setEMail(String eMail) {
		this.eMail = eMail;
	}

	public String getNacionalidad() {
		return this.nacionalidad;
	}

	public void setNacionalidad(String nacionalidad) {
		this.nacionalidad = nacionalidad;
	}

	public String getNombre() {
		return this.nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getTelefono() {
		return this.telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

}