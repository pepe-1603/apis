package com.Aagenda.Controlador;
import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Aagenda.modelo.TContacto;
import com.Aagenda.service.AgendaServicio;


@CrossOrigin(origins = "*")//nos ayuda a incdica a SPring, que cualquier persn que solicite una peticion 
//la podamos realizar
@RestController
public class AgendaControlador {
	/**Agregamos las actividades que realzaremos**/
	@Autowired
	AgendaServicio servicio;//clase importada de Interfaces servicio
	
	//reotnamos todos los contactos
	@GetMapping(value= "contactos",produces = MediaType.APPLICATION_JSON_VALUE)
	public List <TContacto> recuperar(){
		
		return servicio.recuperarContactos();
	}
	
	//devolvemos un contacto
	@GetMapping(value = "contactos/id",produces = MediaType.APPLICATION_JSON_VALUE)
	public TContacto recuperarContacto (@PathVariable("id")int idcontact) {
		
		return servicio.buscarContacto(idcontact);
	}
	
	
	//inserccion o agregar contacto
	@PostMapping(value="contactos",consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.TEXT_PLAIN_VALUE)
	public String agregarContacto(@RequestBody TContacto contacto) {
		/*si agrega el contacto nos regresa true , en caso contrario nos regresara false:
		 * si nos  regresa true , convertimos el metodo de boolean a String*/
		//como obtenderemos un texto plano , por eso convertimos a String (abajo)
		return String.valueOf(servicio.bAgregarContacto(contacto));
		
	}
	
	/*Actualizar*/
	@PutMapping(value="contactos",consumes = MediaType.APPLICATION_JSON_VALUE)
	/*como no producimos nada no se necesita crear un producess*/
	public void actualizarContactos(@RequestBody TContacto contacto) {
		servicio.actualizarContacto(contacto);
	}
	//eliminar contacto
	@DeleteMapping(value="contactos/id")//no producimos ni consumimos nada por k nos envian el dato por url
	public void eliminarContacto(@PathVariable ("id") int contact) {
		servicio.beliminarContacto(contact);
	}
}

