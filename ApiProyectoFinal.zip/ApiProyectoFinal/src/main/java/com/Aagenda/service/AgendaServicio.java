package com.Aagenda.service;

import com.Aagenda.modelo.TContacto;
import java.util.*;

import org.springframework.stereotype.Service;


/*havem,o suso de la capa dao*/
@Service
public interface AgendaServicio {
	
	//1si esta insetado en dato
	boolean bAgregarContacto(TContacto contact);
	
	//listas
	List<TContacto> recuperarContactos();
	
	//actualizar o editar
	void actualizarContacto(TContacto contact);
	//eliminar por id
	boolean beliminarContacto(int idcontact);
	//buscar por id
	TContacto buscarContacto(int idcontact);
}
