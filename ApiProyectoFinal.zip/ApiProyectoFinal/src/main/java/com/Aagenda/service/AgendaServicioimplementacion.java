package com.Aagenda.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Aagenda.modelo.TContacto;
import com.ApiAagenda.dao.Agendadao;

@Service
public class AgendaServicioimplementacion implements AgendaServicio {

	@Autowired
	Agendadao agendaDAO;//objecto de clase AgendaDao (importada)
	
	@Override
	/*Si es falso no agrega el contcto por k ya existe en caso contario lo regitraa*/
	public boolean bAgregarContacto(TContacto contact) {
		// TODO Auto-generated method stub
		if(agendaDAO.recuperarContacto(contact.getIdcontacto())==null) {
			agendaDAO.agregar(contact);
			return true;
		}
		
		return false;
	}

	@Override
	public List<TContacto> recuperarContactos() {
		// TODO Auto-generated method stub
		return agendaDAO.devuelveContactos();
	}

	@Override
	public void actualizarContacto(TContacto contact) {
		// TODO Auto-generated method stub
		if(agendaDAO.recuperarContacto(contact.getIdcontacto())!=null) {
			agendaDAO.actualizarContacto(contact);	
		}
	}

	@Override
	public boolean beliminarContacto(int idcontact) {
		// TODO Auto-generated method stub
		if(agendaDAO.recuperarContacto(idcontact)!=null) {//si_existe_lo_eliminamos
			agendaDAO.delecteContacto(idcontact);
			return true;
		}
		return false;
	}
/*busca_por_id*/ 
	@Override
	public TContacto buscarContacto(int idcontact) {
		// TODO Auto-generated method stub
		return agendaDAO.recuperarContacto(idcontact);
	}

}
